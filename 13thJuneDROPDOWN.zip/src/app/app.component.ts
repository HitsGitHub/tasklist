import { Component,} from '@angular/core';
import {FormBuilder,FormGroup,FormArray} from '@angular/forms';
import { HttpClient} from '@angular/common/http';
import { JsondataService} from './jsondata.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 
  myForm:FormGroup;
  disabled = false;
  ShowFilter = false;
  limitSelection = false;
  country : any = [];
  citiess: any = [];
  state: any = [];
  dropdownSettings1: any = {};
  dropdownSettings2: any = {};
  dropdownSettings3: any = {};
  countrydata = [];
  statedata =[];
  citydata=[];

  AllCountries=[];
  AllStates = [];
  AllCities=[];
  h1 = [];
  h2 = [];

  jsondata : any;

  constructor(private fb: FormBuilder, private http : HttpClient,private jSon:JsondataService) {
    this.myForm = this.fb.group({
      city: [''],
      state: [''],
      country: [''],
      checkbox : new FormArray([])
    });
  }

  ngOnInit() {
      this.jSon.getJsonData().subscribe(response=>{
        
        this.jsondata = response[0];
        this.AllStates = this.jsondata.states;
        this.AllCities = this.jsondata.cities;
        for (let i = 0; i < this.jsondata.countries.length; i++) {
          this.AllCountries.push({item_id: i, item_text: this.jsondata.countries[i].name});
          this.country = this.AllCountries          
        }  
      })
      this.dropdownSettings1 = {
        singleSelection: true,
        idField: 'item_id',
        textField: 'item_text',
        unSelectAllText: 'UnSelect All',
        itemsShowLimit: 3,
        allowSearchFilter: this.ShowFilter
      };
      this.dropdownSettings2 = {
        singleSelection: false,
        idField: 'item_id',
        textField: 'item_text',
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        itemsShowLimit: 3,
        allowSearchFilter: this.ShowFilter
      };
      this.dropdownSettings3 = {
        singleSelection: false,
        idField: 'item_id',
        textField: 'item_text',
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        itemsShowLimit: 3,
        allowSearchFilter: this.ShowFilter
      };
     
  }
  
  onSelectCountry(item : any) {
   console.log("selectedCountry",item);
    
    this.statedata = this.AllStates.filter(x=>
      x.country_id == item.item_id
    )
    for (let i = 0; i < this.statedata.length; i++) {
      this.h1.push({item_id: this.statedata[i].id, item_text:this.statedata[i].name})
      this.state = this.h1;
    }
  }
  onSelectState(item: any) {
    console.log("selected State",item);
  
    this.citydata = this.AllCities.filter(x=>
        x.state_id == item.item_id
      )
      for (let i = 0; i < this.citydata.length; i++) {
        this.h2.push({item_id: this.citydata[i].id,item_text : this.citydata[i].name})        
        this.citiess = this.h2;
      }
  }
  onCitySelect(item: any){
      console.log('SelectCity',item);

  }
  onSelectAll(items: any) {
      console.log('onSelectAll1', items);
  }
  onSelectAll2(items: any) {
    console.log('onSelectAll2', items);
  }
  toogleShowFilter() {
      this.ShowFilter = !this.ShowFilter;
      this.dropdownSettings1 = Object.assign({}, this.dropdownSettings1, { allowSearchFilter: this.ShowFilter });
  }

  handleLimitSelection() {
      if (this.limitSelection) {
          this.dropdownSettings1 = Object.assign({}, this.dropdownSettings1, { limitSelection: 2 });
      } else {
          this.dropdownSettings1 = Object.assign({}, this.dropdownSettings1, { limitSelection: null });
      }
  }
  onSubmit(){
    this.myForm.value("formVlaue");
  }
}
