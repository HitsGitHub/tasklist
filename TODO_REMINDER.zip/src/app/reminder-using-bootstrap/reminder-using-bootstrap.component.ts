import { Component, OnInit, ViewChild, ElementRef,TemplateRef } from '@angular/core';
import { Time } from '@angular/common';
import { FormArray, FormGroup, FormBuilder } from '@angular/forms';
import * as jsPDF  from 'jspdf';
import {HttpClient} from '@angular/common/http';
import { from } from 'rxjs';
import { text } from '@angular/core/src/render3';
import { NgbCheckBox } from '@ng-bootstrap/ng-bootstrap';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-reminder-using-bootstrap',
  templateUrl: './reminder-using-bootstrap.component.html',
  styleUrls: ['./reminder-using-bootstrap.component.css']
})
export class ReminderUsingBootstrapComponent implements OnInit {
  
  modalRef: BsModalRef;
  message: string;
  Date = new Date();
  ctime = Date.now();
  myForm: FormGroup;
  saveData = [];
  taskStatus = [
    { id: 1, status: "Working" },
    { id: 2, status: "Completed" }
  ]

  constructor(private fb: FormBuilder,
    private modalService: BsModalService) {
  }

  ngOnInit() {  
  this.myForm = this.fb.group({
      ctask: "",
      cstatus: "",
      ctime: ""
    }) 
  }
  
  onSubmit() {
    this.saveData.push(this.myForm.value);
    this.myForm.reset();
  }

  openModal(template: TemplateRef<any>) 
  {
    this.modalRef = this.modalService.show(template, {class: 'modal-sm'});
  }
 
  removeRow(id): void {
    for(let i = 0; i < this.saveData.length; ++i){
      if (this.saveData[i].id === id) {
        this.saveData.splice(i,1);
        this.message = 'Confirmed!';
        this.modalRef.hide();
        }
      } 
  }
 
  decline(): void {
    this.message = 'Declined!';
    this.modalRef.hide();
  }

  /* -------- Getting Status -------- */
  onChange(selectedDropValue:any) {
  //console.log(selectedDropValue);
  
  }
/* ---------- Change Status--------- */
  changeStatus(event,id) {
    
    if(event.target.checked)
    {
      this.saveData[id].cstatus ="Completed";
      /* this.saveData[id].ctime = Date.now();  */
      
    }else{

      this.saveData[id].cstatus = "Working";
      /* console.log("pushed data",this.saveData); */
    }  
  }


  /* -----------PDF GENERATE--------- */
  @ViewChild('reportContent') reportContent: ElementRef;
  downloadPdf() {
    
    const doc = new jsPDF('l', 'mm', 'a3');
    const specialElementHandlers = {
      '#editor': function (element, renderer) {
        return true;
      }
    };
    const content = this.reportContent.nativeElement;
    doc.fromHTML(content.innerHTML, 150, 50, {
  
      'width': 100,
      'elementHandlers': specialElementHandlers
    });
    doc.save('ReminderReport' + '.pdf');
  }


}
