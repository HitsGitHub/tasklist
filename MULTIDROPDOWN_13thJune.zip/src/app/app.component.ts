import { Component, ɵɵpipeBind1 } from '@angular/core';
import {FormBuilder,FormGroup,FormArray} from '@angular/forms';
import { HttpClient} from '@angular/common/http';
import { JsondataService} from './jsondata.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 
  myForm:FormGroup;
  disabled = false;
  ShowFilter = false;
  limitSelection = false;
  country : any = [];
  citiess: any = [];
  state: any = [];
  dropdownSettings1: any = {};
  dropdownSettings2: any = {};
  dropdownSettings3: any = {};
  selectedCountry = 0;
  selectedState = 0;
  selectedCities = 0;
 
  countrydata = [];
  statedata =[];
  citydata=[]

  A1=[];
  B1 = [];
  C1=[];
  d1 = [];
  e1 = [];
  jsondata: any  = [];
  constructor(private fb: FormBuilder, private http : HttpClient,private jSon:JsondataService) {
   
  }

  ngOnInit() {
      this.jSon.getJsonData().subscribe(response=>{
        this.jsondata = response[0];
        this.B1 = this.jsondata.states;
        this.C1 = this.jsondata.cities;
        for (let i = 0; i < this.jsondata.countries.length; i++) {
          this.A1.push({item_id: i, item_text: this.jsondata.countries[i].name});
          this.country = this.A1          
        }  
      })
      this.dropdownSettings1 = {
        singleSelection: true,
        idField: 'item_id',
        textField: 'item_text',
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        itemsShowLimit: 3,
        allowSearchFilter: this.ShowFilter
      };
      this.dropdownSettings2 = {
        singleSelection: false,
        idField: 'item_id',
        textField: 'item_text',
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        itemsShowLimit: 3,
        allowSearchFilter: this.ShowFilter
      };
      this.dropdownSettings3 = {
        singleSelection: false,
        idField: 'item_id',
        textField: 'item_text',
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        itemsShowLimit: 3,
        allowSearchFilter: this.ShowFilter
      };
      this.myForm = this.fb.group({
          city: [],
          state: [],
          country: []
      });
  }
  
  onSelectCountry(item : any) {
    this.state = [];
    this.citiess = [];
    this.statedata = this.B1.filter(x=>
      x.country_id == item.item_id
    )
    for (let i = 0; i < this.statedata.length; i++) {
      this.d1.push({item_id: this.statedata[i].id, item_text:this.statedata[i].name})
      this.state = this.d1;
    }
  }
  onSelectState(item: any) {
    this.citydata = this.C1.filter(x=>
        x.state_id == item.item_id
      )
      for (let i = 0; i < this.citydata.length; i++) {
        this.e1.push({item_id: this.citydata[i].id,item_text : this.citydata[i].name})        
        this.citiess = this.e1;
      }
      
  }
  onCitySelect(item: any){
      console.log('onCitySelect',item);

  }
  onSelectAll(items: any) {
      console.log('onSelectAll1', items);

  }
  onSelectAll2(items: any) {
    console.log('onSelectAll2', items);
}
  toogleShowFilter() {
      this.ShowFilter = !this.ShowFilter;
      this.dropdownSettings1 = Object.assign({}, this.dropdownSettings1, { allowSearchFilter: this.ShowFilter });
  }

  handleLimitSelection() {
      if (this.limitSelection) {
          this.dropdownSettings1 = Object.assign({}, this.dropdownSettings1, { limitSelection: 2 });
      } else {
          this.dropdownSettings1 = Object.assign({}, this.dropdownSettings1, { limitSelection: null });
      }
  }
}
