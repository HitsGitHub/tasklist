import { Component, OnInit } from '@angular/core';
import { JsonDataService } from '../json-data.service';
import { Local } from 'protractor/built/driverProviders';
import {FormArray, FormBuilder, FormControl, FormGroup} from '@angular/forms';
@Component({
  selector: 'app-multipledropdown',
  templateUrl: './multipledropdown.component.html',
  styleUrls: ['./multipledropdown.component.css']
})
export class MultipledropdownComponent {
  checkboxgroup: FormGroup;//Checkbox group Array.Form
  CarBrand = [];
  model = [];
  color = [];
  listData = [];
  constructor(private jsonservice : JsonDataService, private _fb: FormBuilder) {

    let checkboxgroupArry = new FormArray([

    ]);
    this.checkboxgroup = _fb.group({

    });
   }

  ngOnInit() {
    this.jsonservice.getJSONData().subscribe(data=>{
        this.CarBrand= data;
    });
 /*    var x = JSON.parse(localStorage.getItem('Brand'));
    console.log(x); */
  }
 
  brandChange(e) {
    localStorage.setItem("Brand",e);
    console.log("Brands",e);// getting selected Brands
    this.CarBrand.filter(element => {  
      if(this.model = element.model)
      this.model = element.model
    
    });
    this.color = []
  }

  modelChange(evt) {

    localStorage.setItem("Model",evt)
    console.log("model",evt);
    
    this.model.filter(element => {
      if (element.name == evt) {
        this.color = element.color;
        localStorage.setItem("color",element.color);
      }
    });
  }
  storeddata(){
   /*  localStorage.getItem("Brand");
    let finalData = localStorage.getItem('Brand');
    console.log("Brands ",finalData); */
  }

}
