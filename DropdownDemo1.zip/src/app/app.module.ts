import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from "@angular/common/http";
import {
  MatSelectModule, MatOptionModule, MatListModule, MatButtonModule,
  MatFormFieldModule,
  MatInputModule,
  MatRippleModule,
} from '@angular/material';
import { MultipledropdownComponent } from './multipledropdown/multipledropdown.component';
@NgModule({
  declarations: [
    AppComponent,
    MultipledropdownComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, FormsModule,HttpClientModule,
    MatSelectModule,
    MatOptionModule, MatListModule,
    MatButtonModule,ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatRippleModule, BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
