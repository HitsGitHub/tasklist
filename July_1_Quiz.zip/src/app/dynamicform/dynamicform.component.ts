import { Component, OnInit } from '@angular/core';
import {QuizDataService} from '../quiz-data.service'
  import { from } from 'rxjs';
  import {FormControl,FormGroup} from '@angular/forms'
@Component({
  selector: 'app-dynamicform',
  templateUrl: './dynamicform.component.html',
  styleUrls: ['./dynamicform.component.css']
})
export class DynamicformComponent implements OnInit {
  title = "DynamicQuizForm"
  thisForm : FormGroup;
  constructor(private jdata : QuizDataService) { }
  QuizData : any [];
  Que : any;
  Answers = []
  typeOfAnswer = []
  QueType = [];
  correctIndex : []
  Ans = [];
  x : number = 0;
  
  ngOnInit() {
    this.jdata.getQuizdata().subscribe(data=>{
      this.QuizData = data.QuizData
      console.log("Quizz",this.QuizData);
      for(let i = 0; i < 5; i++,this.x++) {
       this.Ans.push(this.QuizData[i].answers);  
       this.QueType.push(this.QuizData[i].types)
      }
      this.Answers = this.Ans
      this.typeOfAnswer = this.QueType
    },
    error=>{ 
      console.log("Data Not Fatch",error);
      
    })

    let group={}
    this.QuizData.forEach(types_controls=>{      
      group[types_controls.types]=new FormControl('');
    })
    this.thisForm = new FormGroup(group);
  }
  temp = [];

  nextQuizData(){
    this.Ans=[]
    this.temp = [] 
    console.log("X",this.x);
    for (let i = this.x;i<this.QuizData.length; i++,this.x++)  {      
      this.temp.push(this.QuizData[i]);
      this.Ans.push(this.QuizData[i].answers)
     }
      this.QuizData = this.temp;
      console.log("QQ",this.QuizData);
     this.Answers = this.Ans
     console.log("Thii",this.Answers);
     
  }
  saveAnswer(){
    
  }
  onSubmit(){
    console.log(this.thisForm.value)
  }
}
