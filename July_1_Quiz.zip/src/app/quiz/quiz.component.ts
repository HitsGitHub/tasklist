import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,FormControl,Validators, FormArray} from '@angular/forms'
import { QuizDataService} from '../quiz-data.service';
import { SlicePipe } from '@angular/common';

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {
  quizForm = this.fb.group({
    checkbox : [''],
    radiobutton : [''],
    textbox : ['',Validators.required],
   
    Answers : new FormArray([])
  });

  title = "Quiz Wizard"
  radioSel:any;
  radioSelected:string;
  radioSelectedString:string;
  itemsList: any;
 
  Questions : any 
  Que : any;
  Answers = []
  typeOfAnswer = []
  QueType = [];
  correctIndex : []
  Ans = [];
  x : number = 0
  


  constructor(private quizdataservice: QuizDataService, 
  private fb : FormBuilder){
  }
 
  ngOnInit() {
    this.quizdataservice.getQuizdata().subscribe(data=>{
      this.Questions = data.questions
      for(let i = 0; i < 5; i++,this.x++) {
       this.Ans.push(this.Questions[i].answers)
       this.QueType.push(this.Questions[i].types)
      }
      this.Answers = this.Ans 
      this.typeOfAnswer = this.QueType 
      
    },
    error=>{ 
      console.log("Data Not Fatch",error)
    })
  }
  temp = [];

  nextQuestions(){
    console.log("x",this.x)
    this.Ans = []
    this.QueType = []
    this.temp = []
    
      for(let i = this.x ; i < this.Questions.length; i++,this.x++){
        
        this.temp.push(this.Questions[i])
        this.Ans.push(this.Questions[i].answers)
        this.QueType.push(this.Questions[i].types)
      }
      
      console.log("x",this.x)
      this.Questions = this.temp
      this.Answers = this.Ans
      this.typeOfAnswer = this.QueType
    
    
  }
  saveData(item){
    
  }
   // Get row item from array  
   getSelecteditem(){
   
  }
  // Radio Change Event
  onItemChange(item){
    this.getSelecteditem();
  }
  selectedChBox(items){
    
    console.warn("item",items)
  }
  onSubmit() {
    // TODO: Use EventEmitter with form value
    console.warn(this.quizForm.value);
  }
  checking(){
 
  }
}
