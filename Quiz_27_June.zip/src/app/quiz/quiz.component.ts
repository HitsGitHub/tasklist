import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,FormControl} from '@angular/forms'
import { QuizDataService} from '../quiz-data.service';
import {Router,ActivatedRoute} from '@angular/router'
import * as $ from 'jquery';
@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {
  quizForm : FormGroup;
  title = "Quiz Wizard"
  Questions : any []
  Answers : any[]
  Types : any[]
  correctIndex : []
  Ans = []

  constructor(private quizdataservice: QuizDataService, private fb : FormBuilder,public route: ActivatedRoute, public router: Router) 
  {
   this.quizForm = new FormGroup({
    
   })
  }
  ngOnInit() {
    this.quizdataservice.getQuizdata().subscribe(data=>{
      this.Questions = data.questions
      console.log("Questions",this.Questions);
      for(let i = 0; i < this.Questions.length; i++) {
         this.Types.push(this.Questions[i].type);  
         this.Ans.push(this.Questions[i].answers);
      }
      console.log("types",this.Types);
      this.Answers = this.Ans;
    },
    error=>{
      console.log("Data Not Fatch",error);
      
    })
  }
  onSubmit(){
    console.log(this.quizForm.value)
  }
  getQuestions(){
    return this.Questions
  }
  getAnswer(){
    return this.Answers
  }
  getTypes(){
    return this.Types
  }
  changeLabelName(lbl, val) {
    document.getElementById(lbl).innerHTML = val;
  }  
  gettingQuestioType(){
    
  }
  check(v, i){

  }
}
