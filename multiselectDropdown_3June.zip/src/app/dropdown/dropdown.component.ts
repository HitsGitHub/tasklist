import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder } from '@angular/forms';
import {JsonDataService} from 'src/app/json-data.service';
import {HttpClient} from '@angular/common/http';
import { from } from 'rxjs';
import { importType } from '@angular/compiler/src/output/output_ast';
@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css']
})
        
  
export class DropdownComponent implements OnInit {

  itemList:any = [];
  selectedItems = [];
  settings = {};
  jDATA : any [];
  constructor(private jsndata : JsonDataService, private http : HttpClient) {

   }

  ngOnInit() {
    
   this.jsndata.getJSONData().subscribe(data=>{
      console.log("countries",data[0].countries);
      //this.itemList = data[0].countries;
      let x =  JSON.stringify(data[0].countries) ;
      this.itemList = JSON.parse(x);
      console.log("itemssss",this.itemList);
    }) 
 /* 
    this.http.get('https://restcountries.eu/rest/v2/all').subscribe(res=>{
      console.log("result", res);
      let x =  JSON.stringify(res) ;
      this.itemList = JSON.parse(x);
      console.log("itemssss",this.itemList);
      
    },error=>{

    }); */

    this.selectedItems=[];

    this.settings = {
      text: "Select Countries",
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: "myclass custom-class"
    };
  }
  onItemSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  OnItemDeSelect(item: any) {
      console.log(item);
      console.log(this.selectedItems);
  }
  onSelectAll(items: any) {
      console.log(items);
  }
  onDeSelectAll(items: any) {
      console.log(items);
}
}
