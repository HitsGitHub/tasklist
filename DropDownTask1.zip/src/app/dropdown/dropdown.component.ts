import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms'
import { ShowOnDirtyErrorStateMatcher } from '@angular/material/core';
import { JsondataService } from '../jsondata.service';
import { Data } from '@angular/router';

export interface Car {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css']
})
export class DropdownComponent {
  
  cars: Car[] = [
    
    { value: 'jaguar', viewValue: 'JAGUAR' },
    { value: 'bmw', viewValue: 'BMW' },
    { value: 'audi', viewValue: 'AUDI' }
  ];
  constructor(private jsonDataService : JsondataService) { }

  ngOnInit() {
    this.jsonDataService.getJSON().subscribe(data => {
      //  console.log(data);
      console.log(data.cars);
      console.log( typeof data.cars);
      let jsonObject = JSON.stringify(data);
      console.log("jdata", typeof jsonObject);
      
    });
  }
}
