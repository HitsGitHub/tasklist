import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators, FormArray } from '@angular/forms'
import { QuizDataService } from '../quiz-data.service';


@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {
  quizForm: FormGroup;
  title = "Quiz Wizard"
  radioSel: any;
  radioSelected: string;
  radioSelectedString: string;
  itemsList: any;

  Questions: any
  Que: any;
  Answers = []
  typeOfAnswer = []
  QueType = [];
  correctIndex: []
  Ans = [];
  x: number = 0
  QQ1: any

  constructor(private quizdataservice: QuizDataService,
    private fb: FormBuilder) {
    this.quizForm = this.fb.group({

      btn_radio: ['',Validators.required],
      textbox: ['', Validators.required],
      val_check: this.fb.array([]),
      
    })
  }

  ngOnInit() {
    this.quizdataservice.getQuizdata().subscribe(data => {
      this.Questions = data.questions
      
      for (let i = 0; i < 5; i++ , this.x++) {
        this.Ans.push(this.Questions[i].answers)
        this.QueType.push(this.Questions[i].types)
      }
     this.Answers = this.Ans
      this.typeOfAnswer = this.QueType
      /* ---------------------- */
   /*    this.Questions.types.forEach(aa=>{
        console.log("aa",aa);
        
       this.quizForm.addControl(aa.questions,this.fb.control(null, Validators.required));
        
      }) */
      /* ---------------------- */

    },
      error => {
        console.log("Data Not Fatch", error)
      })

   
    
  }
  temp = [];

  nextQuestions() {
    this.Ans = []
    this.QueType = []
    this.temp = []

    let count = 0;
    for (let i = this.x; i < this.Questions.length; i++ , this.x++ , count++) {
      if (count <= 4) {
        this.temp.push(this.Questions[i])
        this.Ans.push(this.Questions[i].answers)
        this.QueType.push(this.Questions[i].types)
      }
      else {
        this.Questions = this.temp
        this.Answers = this.Ans
        this.typeOfAnswer = this.QueType
        count = 0
        continue
      }
      console.log("x", this.x)
    }
  }

  // Get row item from array  
  getSelecteditem() {

  }
  onRadioBtnChange(value,i) {
    this.Answers.forEach(item => {
      
      if (item.id !== i) {
        item.selected = false;
      } else {
        item.selected = true;
      }
    })
  }
  selectedChBox(value: string, i, isChecked: boolean) {
    const ChkBoxFormArray = <FormArray>this.quizForm.controls.val_check;

    if (isChecked) {
      ChkBoxFormArray.push(new FormControl(value));
    } else {
      let index = ChkBoxFormArray.controls.findIndex(x => x.value == value)
      ChkBoxFormArray.removeAt(index);
    }

  }
  onSubmit() {
    console.log(this.quizForm.value);
    localStorage.setItem("QuizAnswer", JSON.stringify(this.quizForm.value));
  }
  checking() {

  }
}
