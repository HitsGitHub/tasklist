import { Component, OnInit } from '@angular/core';
import { JsonService } from '../json.service';
import { from } from 'rxjs';
import { FormGroup, FormBuilder } from '@angular/forms';
import { element } from 'protractor';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-ng-multi-dropdown',
  templateUrl: './ng-multi-dropdown.component.html',
  styleUrls: ['./ng-multi-dropdown.component.css']
})
export class NgMultiDropdownComponent implements OnInit {
  myForm: FormGroup;
  dropdownList1 = [];
  dropdownList2 = [];
  selectedItems = [];
  dropdownSettings = {};
  allData: any[];
  car: any[];
  car_model: any[];
  finaldata: any[];
  xyz: any[];
  CarBrand = [];

  constructor(private jsonService: JsonService, private _fb: FormBuilder, private http: HttpClient) {

  }

  ngOnInit() {

    //this.getData();

    let tmpp = [];
    this.jsonService.getJsonData().subscribe(data => {
      this.allData = data;
      this.xyz =data;
      for (let i = 0; i < data.length; i++) {
        tmpp.push({ item_id: i, item_text: data[i].car });       
      }
      this.dropdownList1 = tmpp;
    });

    this.selectedItems = [
    ];

    this.myForm = this._fb.group({
      dropdownList: [this.selectedItems]
    });

    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 5,
      allowSearchFilter: false
    };
  }
  onItemSelect(item: any) {

    this.dropdownList2 = this.xyz.filter(con =>{
      
      if(con.car == item){
        
      }
      console.log("connnnn",con);
    })
       

    /* for (let i = 0; i < this.xyz.length; i++) {
      for(let j=0;j<this.xyz[i].car.length;j++){
        const element = this.xyz[i].model[j].name;
        console.log("element",element);        
        this.dropdownList.push(element);
      }
    } */

   /*  localStorage.setItem("Brand", item.name);
    this.CarBrand.filter(element => {

      if (element.car == item) {
        this.dropdownList2 = element.model;
      }
    }); */
    /*  this.filteredCities = this.countries.find(con => con.countryName == count).cities;
    this.filteredCities.filter((x) => {
        this.filteredCities1.push(x);
    }) */

    /*  console.log("selected car",item);
     this.finaldata.splice(0);
     // Filter items and pass into finaldata
     this.finaldata = item.filter(x => x.model_id == item.target.value);
     this.dropdownList.push(this.finaldata);
      */
  }
  onSelectAll(items: any) {
    console.log("All selected", items);

  }

  /* getData(): void {
   let tmp = [];
   this.http.get<any>('https://jsonplaceholder.typicode.com/users').subscribe(data => {
     console.log("sitedata",data);
     
     for(let i=0; i < data.length; i++) {
       tmp.push({ item_id: i, item_text: data[i].name });
     }
     this.dropdownList = tmp;
   });
 } */
}
