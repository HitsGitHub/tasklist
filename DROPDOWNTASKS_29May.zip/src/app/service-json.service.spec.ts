import { TestBed } from '@angular/core/testing';

import { ServiceJSONService } from './service-json.service';

describe('ServiceJSONService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ServiceJSONService = TestBed.get(ServiceJSONService);
    expect(service).toBeTruthy();
  });
});
