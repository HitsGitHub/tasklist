import { Component, OnInit } from '@angular/core';
import { ServiceJSONService } from '../service-json.service';
import { Subscriber } from 'rxjs';

@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css']
})
export class DropdownComponent implements OnInit {
  Brands = [];
  models = [];
  selectedBrand : string;
  public CarBrand : any [] = [] ;
  public finaldata: any [] = [];

  constructor(private jsondata : ServiceJSONService ) { }

  ngOnInit() {
    this.jsondata.getJSONData().subscribe(data=>{
      for (let i = 0; i < data.length; i++) {
        const element = data[i].car;
        
        this.Brands.push(element); 
      }
   });
  }
  
  changeModels(evt){
    this.finaldata.splice(0);
    // Filter items and pass into finaldata
    this.finaldata = this.Brands.filter(x => x.did == evt.target.value);
    this.models.push(this.finaldata);
  }
}
