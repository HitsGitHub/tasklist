import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from "ngx-toastr";
import { ActivatedRoute,Params } from '@angular/router';
import { Location } from "@angular/common";
import { FormControl,FormGroup, FormBuilder } from '@angular/forms';

import { AuthService } from  '../auth.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
/*   
  public popoverTitle: string = 'Are You Sure?';
  public popoverMessage: string = 'Wanna Delete this Record?';
  public confirmClicked: boolean = false;
  public cancelClicked: boolean = false;
  private path;
  */
   
  constructor(private route: Router,
    private location: Location,
    private toast: ToastrService,
    private activeRoute: ActivatedRoute,
    private fb : FormBuilder,
    private authService: AuthService) { }
    
    myNames = [];
    myEmail = [];
    myDOB = [];
    myMobile = [];
    myGender = [];
    myAdd = [];
    storedData = [];

  ngOnInit() {
      history.pushState(null, null, location.href);
      window.onpopstate = function (event) {
      history.go(1);
    };      
    this.retriveData();
  }

  retriveData() {
    this.storedData = JSON.parse(localStorage.getItem("Data"));
    for (let i = 0; i < this.storedData.length; i++) {
      this.myNames[i] = this.storedData[i].name;
      this.myEmail[i] = this.storedData[i].mail;
      this.myDOB[i] = this.storedData[i].bod;
      this.myMobile[i] = this.storedData[i].mono;
      this.myGender[i] = this.storedData[i].gender;
      this.myAdd[i] = this.storedData[i].add;
    }
  }

  deleteUser(id: number, index: number) {
    if (confirm("You Wanna Delete this Record??")){
      this.storedData = JSON.parse(localStorage.getItem("Data"));
      index = this.storedData.indexOf(id);
      console.log(index);
      this.myNames.splice(id, 1) && this.storedData.splice(id, 1);
      localStorage.setItem('Data', JSON.stringify(this.storedData));
    }
  }

  editUser(i:number): void {
    this.route.navigate(['/register', { index: i }]);
  }

  logout() {
    this.authService.logout();
    this.route.navigate(['/login']);
    location.hash = "noBack";
    return false;
  }
}
