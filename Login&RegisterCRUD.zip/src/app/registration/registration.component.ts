import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, } from '@angular/forms';
import { CustomValidators } from 'ng2-validation';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})

export class RegistrationComponent implements OnInit {
  registerForm: FormGroup;

  ind: number
  arryData = [] // all Form Data Store in this Array
  newData = []

  constructor(private fb: FormBuilder,
    private route: Router,
    private toast: ToastrService,
    private activatedRoute: ActivatedRoute
  ) { }
  ngOnInit() {
    let password = new FormControl(null, Validators.compose([Validators.required, Validators.minLength(6)]));
    let confirm_password = new FormControl(null, Validators.compose([Validators.required, CustomValidators.equalTo(password)]));
    this.registerForm = this.fb.group({
      name: ['', Validators.required],
      bod: ['', Validators.required],
      add: ['', Validators.required],
      mono: [null, Validators.compose([Validators.required, Validators.pattern("[0-9][0-9\s]*"), Validators.maxLength(10), Validators.minLength(10)])],
      gender: ['', Validators.required],
      mail: ['', Validators.compose([Validators.required, Validators.email])],
      pass: password,
      cpass: confirm_password,
    });

    /*.........patch value Code...... */

    if (this.activatedRoute.snapshot.queryParams['ind']) {
      this.activatedRoute.queryParams.subscribe(params => {
        this.ind = params['ind'];
        var retrievedData1 = localStorage.getItem("Data");
        this.arryData = JSON.parse(retrievedData1);
        this.newData.push(this.arryData[this.ind]);
        this.registerForm.patchValue(this.arryData[this.ind]);
      });

    }
  }
  get f() { return this.registerForm.controls; }

  submitForm($ev, value: any) {
    for (let val in this.registerForm.controls) {
      this.registerForm.controls[val].markAsTouched();
    };
    if (this.registerForm.valid) {
      var dataObject = this.registerForm.value;
      var array = JSON.parse(localStorage.getItem('Data') || '[]');
      array.push(dataObject);
      localStorage.setItem('Data', JSON.stringify(array));
      this.toast.success("Congtrats!! Registration Success");
      this.route.navigate(['/login']);
    }
  }

  EmailCheck() {
    let LoclStorData = JSON.parse(localStorage.getItem('Data'));
    for (let i = 0; i < LoclStorData.length; i++) {
      if (this.registerForm.get('mail').value == LoclStorData[i].mail) {
        this.toast.warning("User is Already Exist! Try Another Email");

      }
    }
  }

  updateRecord() {
    if(this.registerForm.invalid){
        alert("First you have to Register your self");
    }
    else{
      if (confirm("Do you want to Update ?")) {

        // store current record into abc
        var currentRecord = this.registerForm.value;
        // Get back Record from "DATA" from local storage
        var GetRecord = JSON.parse(localStorage.getItem("Data"));
        //GetRecord[0].mail="admin1@gmail.com";
        GetRecord[this.ind] = currentRecord;
        // save edited record into localstorage
        localStorage.setItem("Data", JSON.stringify(GetRecord));
        this.route.navigate(['/dashboard']);
        return true;
      }
    }
  }
}
/*
Validators.pattern("[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?")
         ]),
 */