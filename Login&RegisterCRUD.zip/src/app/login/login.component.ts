import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ToastrService, Toast } from 'ngx-toastr';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;

  constructor(private fb: FormBuilder,
    private toast: ToastrService,
    private route: Router,
    private authService: AuthService) {
  }
  ngOnInit() {

    let password = new FormControl(null, Validators.compose([Validators.required, Validators.minLength(6)]));
    this.loginForm = this.fb.group({
      mail: ['', Validators.compose([Validators.required, Validators.email])],
      pass: password,
    });
  }
  submitForm($ev, value: any) {

    for (let val in this.loginForm.controls) {
      this.loginForm.controls[val].markAsTouched();
    };
    if (this.loginForm.valid) {
      let logFormMail = this.loginForm.get('mail').value;
      let logFormPass = this.loginForm.get('pass').value;
      let LoclStorData = JSON.parse(localStorage.getItem('Data'));

      for (let i = 0; i < LoclStorData.length; i++) {
        if (logFormMail == LoclStorData[i].mail && logFormPass == LoclStorData[i].pass) {
          this.toast.success("Login Success!!!!!");
          this.route.navigate(["/dashboard"]);
        }
        if (logFormMail != LoclStorData[i].mail && logFormPass != LoclStorData[i].pass) {
          this.toast.error("Incorrect email or password");
        }
      }
    }
  }
}
   /* <<<<<<<<<<<< Code for Login With Sigle Object Data >>>>>>>>>>>>> */
/* var x = JSON.parse(localStorage.getItem("DATAKEY"));
if(this.loginForm.get("mail").value == x.mail && this.loginForm.get("pass").value == x.pass)
{
  this.toast.success("Login Success!!!!!");
    this.route.navigate(["/dashboard"]);
}*/

