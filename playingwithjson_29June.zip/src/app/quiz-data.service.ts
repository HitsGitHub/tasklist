import { Injectable } from '@angular/core'
import {HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs'
@Injectable({
  providedIn: 'root'
})
export class QuizDataService {
  questionId : Number;
  answers = [];
  questions : any [];
  constructor(private http : HttpClient) { 
  this.getQuizdata().subscribe(data=>{
    this.questions.push(data.questions)
    this.answers.push(data.answers)
    console.log(this.answers);
    
  })
  }

  public getQuizdata():Observable<any>{
    return this.http.get("assets/quizdata.json")
  }
}
