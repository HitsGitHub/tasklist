import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,FormControl,Validators} from '@angular/forms'
import { QuizDataService} from '../quiz-data.service';

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {
  quizForm : FormGroup;
  title = "Quiz Wizard"
  Questions : any 
  Que : any;
  Answers = []
  typeOfAnswer = []
  QueType = [];
  correctIndex : []
  Ans = [];
  x : number = 0;

  

  constructor(private quizdataservice: QuizDataService, 
  private fb : FormBuilder){
  
  }
  ngOnInit() {
    this.quizdataservice.getQuizdata().subscribe(data=>{
      this.Questions = data.questions      
      for(let i = 0; i < 5; i++,this.x++) {
       this.Ans.push(this.Questions[i].answers);  
       this.QueType.push(this.Questions[i].types)
      }
      this.Answers = this.Ans
      this.typeOfAnswer = this.QueType
      
    },
    error=>{ 
      console.log("Data Not Fatch",error);
      
    })
    
  }
  temp = [];

  nextQuestions(){
    this.Ans=[]
    this.temp = [] 
    console.log("X",this.x);
    for (let i = this.x;i<this.Questions.length; i++,this.x++)  {      
      this.temp.push(this.Questions[i]);
      this.Ans.push(this.Questions[i].answers)
     }
      this.Questions = this.temp;
      console.log("QQ",this.Questions);
     this.Answers = this.Ans
     console.log("Thii",this.Answers);
     
  }
  saveAnswer(item,index){
    
  }

  onSubmit(){
    console.log(this.quizForm.value)

  }
}
