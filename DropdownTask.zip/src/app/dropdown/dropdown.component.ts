import { Component, OnInit } from '@angular/core';


export interface Food {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css']
})
export class DropdownComponent {
 
  foods: Food[] = [
    {value: 'burgger-0', viewValue: 'Burgger'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'cake-2', viewValue: 'Cake'}
  ];
  constructor() { }

  ngOnInit() {
  }
}
