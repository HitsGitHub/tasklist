import { Component, OnInit } from '@angular/core';
import { JsonDataService } from '../json-data.service'
import { Subscriber } from 'rxjs';
import {Department,Employee} from '../dropdown-cascade/modelfordropdown';
@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css']
})
export class DropdownComponent implements OnInit {

  // Initilize Department Class
  departments: Department[] = [
    { id: 1, name: 'HR' },
    { id: 2, name: 'NT' },
    { id: 3, name: 'Designer' },
    { id: 4, name: 'MKT' },
    { id: 5, name: 'SEO'},
    { id : 6, name : 'DEVELOPER'}
  ];
  // Initilize employee class
  emps: Employee[] = [
    { eid: 1, empname: 'Hemndri', did: 1 },
    { eid: 2, empname: 'Sujata', did: 1 },
    { eid: 3, empname: 'Yashesh', did: 2 },
    { eid: 4, empname: 'Dhaval', did: 3 },
    { eid: 5, empname: 'Nikit', did: 3 },
    { eid: 6, empname: 'Maulik', did: 3 },
    { eid: 7, empname: 'Chirag', did: 3 },
    { eid: 8, empname: 'Harshita', did: 4 },
    { eid: 9, empname: 'Helly', did: 4 },
    { eid: 10, empname: 'Shivani', did: 4 },
    { eid : 11, empname : 'Tarang', did:5},
    { eid : 12, empname : 'Vimal', did:5},
    { eid : 13, empname : 'Hitesh', did:6},
  ];
  // create an array to stored filtered data which will be added into second dropdown
  public finaldata: any[] = [];

  constructor() {

  }
  // Following event will be called when user select item in first dropwdown.
  changedata($event) {
    // To remove previous selected items from second dropdown 
    this.finaldata.splice(0);
    // Filter items and pass into finaldata
    this.finaldata = this.emps.filter(x => x.did == $event.target.value);
  }

  ngOnInit() { }
 /*  Brands = [];
  selectedBrand = 0;
  selectedModel = 0;
  models = [];
  Carmodels: Array<any>;
  CarBrand : any [] ;
  constructor(private jsondata : JsonDataService ) { }

  ngOnInit() {
    this.jsondata.getJSONData().subscribe(data=>{
      this.CarBrand = data;
      //console.log("carBrand",this.CarBrand);
      
      for(let i = 0; i < data.length;i++){
       this.Brands.push(data[i].carname);
        console.log("Brands",this.Brands);
      }

      for(let i = 0; i < data.length;i++){
        this.models.push(data[i].carmodel);
        console.log("model_name",this.models);
      } 
    });
     
  }
  changeModels(e){
    console.log("e",e);
    this.CarBrand.filter(element =>{
      if(element.car == e){
        this.models = element.model
      }
    })
  } */
}
