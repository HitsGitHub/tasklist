import { Component, OnInit } from '@angular/core';
import { Employee, Department } from './modelfordropdown';
@Component({
  selector: 'app-dropdown-cascade',
  templateUrl: './dropdown-cascade.component.html',
  styleUrls: ['./dropdown-cascade.component.css']
})
export class DropdownCascadeComponent implements OnInit {
  // Initilize Department Class
  departments: Department[] = [
    { id: 1, name: 'HR' },
    { id: 2, name: 'NT' },
    { id: 3, name: 'Designer' },
    { id: 4, name: 'MKT' },
    { id: 5, name: 'SEO'},
    { id : 6, name : 'DEVELOPER'}
  ];
  // Initilize employee class
  emps: Employee[] = [
    { eid: 1, empname: 'Hemndri', did: 1 },
    { eid: 2, empname: 'Sujata', did: 1 },
    { eid: 3, empname: 'Yashesh', did: 2 },
    { eid: 4, empname: 'Dhaval', did: 3 },
    { eid: 5, empname: 'Nikit', did: 3 },
    { eid: 6, empname: 'Maulik', did: 3 },
    { eid: 7, empname: 'Chirag', did: 3 },
    { eid: 8, empname: 'Harshita', did: 4 },
    { eid: 9, empname: 'Helly', did: 4 },
    { eid: 10, empname: 'Shivani', did: 4 },
    { eid : 11, empname : 'Tarang', did:5},
    { eid : 12, empname : 'Vimal', did:5},
    { eid : 13, empname : 'Hitesh', did:6},
  ];
  // create an array to stored filtered data which will be added into second dropdown
  public finaldata: any[] = [];

  constructor() {

  }
  // Following event will be called when user select item in first dropwdown.
  changedata($event) {
    // To remove previous selected items from second dropdown 
    this.finaldata.splice(0);
    // Filter items and pass into finaldata
    this.finaldata = this.emps.filter(x => x.did == $event.target.value);
  }

  ngOnInit() { }

}
