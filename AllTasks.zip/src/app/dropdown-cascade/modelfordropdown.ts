export class Department {
    id: number;
    name: string;
 }
 export class Employee
 {
    eid: number;
    empname: string;
    did : number;
 }