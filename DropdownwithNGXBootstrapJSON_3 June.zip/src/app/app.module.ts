import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from "@angular/common/http";

import { MultipledropdownComponent } from './multipledropdown/multipledropdown.component';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { AlertModule } from 'ngx-bootstrap/alert';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import {NgMultiSelectDropDownModule} from 'ng-multiselect-dropdown';

@NgModule({
  declarations: [
    AppComponent,
    MultipledropdownComponent
  ],
  imports: [
    BrowserModule,NgMultiSelectDropDownModule.forRoot(),
    AppRoutingModule, FormsModule,HttpClientModule,
    ReactiveFormsModule,
    AccordionModule.forRoot(),
    AlertModule.forRoot(),
    ButtonsModule.forRoot(),
   
    BsDatepickerModule.forRoot(),
    BsDropdownModule.forRoot(),
    ],
      providers: [],
      bootstrap: [AppComponent]
})
export class AppModule { }
