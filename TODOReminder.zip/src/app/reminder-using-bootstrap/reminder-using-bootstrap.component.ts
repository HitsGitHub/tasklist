import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Time } from '@angular/common';
import { FormArray, FormGroup, FormBuilder } from '@angular/forms';
import * as jsPDF  from 'jspdf';
import * as jspdf from 'jspdf';  
import html2canvas from 'html2canvas'; 
import { pbkdf2 } from 'crypto';

@Component({
  selector: 'app-reminder-using-bootstrap',
  templateUrl: './reminder-using-bootstrap.component.html',
  styleUrls: ['./reminder-using-bootstrap.component.css']
})
export class ReminderUsingBootstrapComponent implements OnInit {

  myForm: FormGroup;
  saveData = [];
  taskStatus = [
    { id: 1, status: "Started" },
    { id: 2, status: "Late" },
    { id: 3, status: "Today" },
    { id: 4, status: "Upcoming" },
    { id: 5, status: "Completed" }
  ]

  constructor(private fb: FormBuilder) {

  }

  ngOnInit() {

    this.myForm = this.fb.group({
      ctask: "",
      cstatus: "",
    })
  }
  /* ======CURENT TIME======== */
  today = Date.now();
  fixedTimezone = this.today

  onChange(statusindex) {

  }
  onSubmit() {

    const cTime = new Date().toLocaleString();
    /* console.log(cTime); */

    this.saveData.push(this.myForm.value);
    //console.log(this.saveData);

  }

  /* GENERATE PDF REPORT START */
  @ViewChild('reportContent') reportContent: ElementRef;

  downloadPdf() {
    const doc = new jsPDF();
    const specialElementHandlers = {
      '#editor': function (element, renderer) {
        return true;
      }
    };
    const content = this.reportContent.nativeElement;
    doc.fromHTML(content.innerHTML, 15, 10, {
      'position': 'Landscap',
      'width': 0,
      'elementHandlers': specialElementHandlers
    });
    doc.save('ReminderReport' + '.pdf');
  }

  /* captureScreen()  
  {  
    var data = document.getElementById('contentToConvert');  
    html2canvas(data).then(canvas => {  
      // Few necessary setting options  
      var imgWidth = 208;   
      var pageHeight = 295;    
      var imgHeight = canvas.height * imgWidth / canvas.width;  
      var heightLeft = imgHeight;  
  
      const contentDataURL = canvas.toDataURL('image/png')  
      let pdf = new jspdf('p', 'mm', 'a4'); // A4 size page of PDF  
      var position = 0;  
      const specialElementHandlers = {
        '#editor': function (element, renderer) {
          return true;
        }
      };
      const content = this.reportContent.nativeElement;
    pdf.fromHTML(content.innerHTML, 15, 10, {
      'width': 170,
      'elementHandlers': specialElementHandlers
    });
       pdf.save('ReminderReport' + '.pdf');
      pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight)  
      pdf.save('MYPdf.pdf'); // Generated PDF   
    });  
  }   */
}
