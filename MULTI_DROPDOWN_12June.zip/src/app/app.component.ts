import { Component } from '@angular/core';
import {FormBuilder,FormGroup,FormArray} from '@angular/forms';
import { HttpClient} from '@angular/common/http';
import { JsondataService} from './jsondata.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 
  myForm:FormGroup;
  disabled = false;
  ShowFilter = false;
  limitSelection = false;
  country : any = [];
  citiess: any = [];
  state: any = [];
  dropdownSettings1: any = {};
  dropdownSettings2: any = {};
  dropdownSettings3: any = {};
  selectedCountry = 0;
  selectedState = 0;
  selectedCities = 0;
 
  countrydata = [];
  statedata =[];
  citydata=[]

  A1=[];
  B1 = [];
  C1=[];
  jsondata: any  = [];
  constructor(private fb: FormBuilder, private http : HttpClient,private jSon:JsondataService) {
   
  }

  ngOnInit() {
      this.jSon.getJsonData().subscribe(response=>{
        this.jsondata = response;
        /* this.countrydata = response[0].countries;
        this.statedata = response[0].states;
        this.citydata = response[0].cities; */
          
        for (let i = 0; i < response[0].countries.length; i++) {
          this.A1.push({item_id : i, item_text : response[0].countries[i].name});
          this.country = this.A1;
          /* this.B1.push({item_id : i, item_text:response[0].states[i].name});
          this.state = this.B1;

          this.C1.push({item_id : i, item_text:response[0].cities[i].name});
          this.citiess = this.C1; */
        }    
      })
     
      this.dropdownSettings1 = {
        singleSelection: true,
        idField: 'item_id',
        textField: 'item_text',
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        itemsShowLimit: 20,
        allowSearchFilter: this.ShowFilter
      };
      this.dropdownSettings2 = {
        singleSelection: false,
        idField: 'item_id',
        textField: 'item_text',
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        allowSearchFilter: this.ShowFilter
      };
      this.dropdownSettings3 = {
        singleSelection: false,
        idField: 'item_id',
        textField: 'item_text',
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
       
        allowSearchFilter: this.ShowFilter
      };
      this.myForm = this.fb.group({
          city: [],
          state:[],
          country : []
      });
  }
  
  onSelectCountry(e) {
    console.log("e.item_id",e.item_id);
    console.log("e.item_text",e.item_text);
    this.selectedCountry = e.item_id;
    console.log("this.selectedCountry",this.selectedCountry);

    this.jsondata.filter(element=>{
      console.log("element.countries[0].id",element.countries[0].id);
      
      /*  if(element.countries[0].id == e.item_id){

       } */
       
      for (let i = 0; i < element.length; i++) {
       if(element.countries[i].id == e.item_id){
         console.log("element.countries[i].id",element.countries[i].id);
         
          this.B1.push({item_id:i, item_text:element.states[i].name});
          this.state = this.B1;
        }   
      } 
    })
    
    /* this.selectedCountry = country_id;    
    this.selectedState = 0;
    this.citiess = [];
    this.state = this.jsondata.filter((item) => {
      return item.country_id === Number(item)
    });
    console.log("tasas",this.statedata);
     */
  }
  onSelectState(state_id: number) {
    
    this.citiess = this.jsondata().filter((item) => {
      return item.state_id === Number(state_id)
    });
  }
  onCitySelect(item: any){
      console.log('onCitySelect',item);
    
  }
  onSelectAll(items: any) {
      console.log('onSelectAll', items);
  }
  toogleShowFilter() {
      this.ShowFilter = !this.ShowFilter;
      this.dropdownSettings1 = Object.assign({}, this.dropdownSettings1, { allowSearchFilter: this.ShowFilter });
  }

  handleLimitSelection() {
      if (this.limitSelection) {
          this.dropdownSettings1 = Object.assign({}, this.dropdownSettings1, { limitSelection: 2 });
      } else {
          this.dropdownSettings1 = Object.assign({}, this.dropdownSettings1, { limitSelection: null });
      }
  }
}
