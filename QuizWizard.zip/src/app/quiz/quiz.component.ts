import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,FormControl} from '@angular/forms'
import { QuizDataService} from '../quiz-data.service';

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {
  quizForm : FormGroup;
  questions : any [];
  answers : any[];
  types : any;
  
  constructor(private quizdataservice: QuizDataService, private fb : FormBuilder) 
  {
    this.quizdataservice.getQuizdata().subscribe(data=>{
      console.log("jsondata",data);
      
    },
    error=>{
      console.log("Data Not Fatch",error);
      
    })
  }

  ngOnInit() {
  
  }
  onSubmit(){

  }

}
