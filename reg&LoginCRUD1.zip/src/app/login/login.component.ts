import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ToastrService, Toast } from 'ngx-toastr';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { ConcatSource } from 'webpack-sources';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;

  constructor(private fb: FormBuilder,
    private toast: ToastrService,
    private route: Router,
    private authService: AuthService) {
  }
  ngOnInit() {

    let password = new FormControl(null, Validators.compose([Validators.required, Validators.minLength(6)]));
    this.loginForm = this.fb.group({
      mail: ['', Validators.compose([Validators.required, Validators.email])],
      pass: password,
    });
  }
  get f() { return this.loginForm.controls; }

 /*  onSubmit()
  {
    if (this.loginForm.invalid) {
      let user = this.loginForm.value.mail;
      let Password = this.loginForm.value.pass;
      if (user == "" && Password == ""){
         this.toast.warning("UserId and Password cannot be empty" ) }
      else if (user == "") { 
        this.toast.warning("UserId cannot be empty")
       }
      else if (Password == "") { 
        this.toast.warning("Password cannot be empty")
       }
      else { this.toast.warning("Please check your userid and password")
     }
      return;
    }
    else {
      if (this.f.userid.value == this.model.userid && this.f.password.value == this.model.password) {
        localStorage.setItem('isLoggedIn', "true");
        localStorage.setItem('token', this.f.userid.value);
        this.route.navigate([this.loginForm]);
      }
      else {
        this.message = "Please check your userid and password";
      }
    }
  }
   */
  submitForm($ev, value: any) {
    for (let val in this.loginForm.controls) {
    this.loginForm.controls[val].markAsTouched();
    };
    let logFormMail = this.loginForm.get('mail').value;
    let logFormPass = this.loginForm.get('pass').value;
    let LoclStorData = JSON.parse(localStorage.getItem('Data'));
    
    if(this.loginForm.valid){
      for (let i = 0; i < LoclStorData.length; i++)
          if (logFormMail == LoclStorData[i].mail && logFormPass == LoclStorData[i].pass) {
          this.toast.success("Login Success!!!!!");
          this.route.navigate(["/dashboard"]);
          }
          else if(logFormMail !== localStorage[i].mail && logFormPass !== localStorage[i].pass){
            this.toast.error("Both id passsword Invalid");
          } 
          
      }
      return true;
  }

}
