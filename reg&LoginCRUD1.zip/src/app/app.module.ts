import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Inject, Injectable,Component  } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ToasterModule, ToasterService } from 'angular2-toaster';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {ToastrModule} from 'ngx-toastr';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ConfirmationPopoverModule } from 'angular-confirmation-popover';
import { Routes, RouterModule } from '@angular/router';
import { ModalModule } from 'ngx-bootstrap/modal';

const routes: Routes = [
  { path: ':status', component: DashboardComponent },
  { path: 'register/:id', component: RegistrationComponent },
  { path: '**', redirectTo: '/all' }
];
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
    DashboardComponent,
    

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    ToasterModule,
    BrowserAnimationsModule,
    RouterModule.forRoot(routes),
    ConfirmationPopoverModule.forRoot({
      confirmButtonType: 'danger' // set defaults here
    }),
    ModalModule.forRoot(),
    ToastrModule.forRoot(
      {  timeOut: 5000,
        positionClass: 'toast-top-right',
        preventDuplicates: true,}
    )
  ],
  providers: [ToasterService],
  bootstrap: [AppComponent]
})
export class AppModule { }
