import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MultipledropdownComponent } from './multipledropdown/multipledropdown.component';

const routes: Routes = [
  { 
    path: '', 
    redirectTo: 'dropdownDemo', 
    pathMatch: 'full',
  },
  { 
    path: 'dropdownDemo', 
    component:MultipledropdownComponent,
  },
  { path: '**',redirectTo:'dropdownDemo'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
