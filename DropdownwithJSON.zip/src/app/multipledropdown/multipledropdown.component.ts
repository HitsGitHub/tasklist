import { Component, OnInit } from '@angular/core';
import { JsonDataService } from '../json-data.service';
import { Local } from 'protractor/built/driverProviders';
import {FormArray, FormBuilder, FormControl, FormGroup} from '@angular/forms';
import {MatFormFieldControl} from '@angular/material';
import { element } from '@angular/core/src/render3';
import { keyframes } from '@angular/animations';
@Component({
  selector: 'app-multipledropdown',
  templateUrl: './multipledropdown.component.html',
  styleUrls: ['./multipledropdown.component.css']
})
export class MultipledropdownComponent {
  checkboxgroup: FormGroup;//Checkbox group Array.Form
  CarBrand = [];
  model = [];
  color = [];
  listData = [];

   selectedOption: string;
  printedOption: string;

  constructor(private jsonservice : JsonDataService, private _fb: FormBuilder) {

    let checkboxgroupArry = new FormArray([

    ]);
    this.checkboxgroup = _fb.group({

    });
   }

  ngOnInit() {
    this.jsonservice.getJSONData().subscribe(data=>{
        this.CarBrand= data;
        
    });
  }
 
  brandChange(e) {
    this.CarBrand.filter(element => {  
        if(element.car == e){
          this.model = element.model;
      }    
      console.log(e, ' ',element.car,'', element.checked,' ', element.model,'',); 
    });

    this.color = []
        
    /* this.CarBrand.filter(element => {  
      if(element.car == e)
      this.model = element.model
      console.log(element.car);
      //console.log(e, ' ', e.checked,' ', element.car); 
    });
    this.color = []
     */
  }

  modelChange(evt) {

    localStorage.setItem("Model",evt)
    this.model.filter(element => {
      if (element.name == evt) {
        this.color = element.color;
       
      }
    });
  }

  btnSave(keyValu){
    Object.keys(localStorage);
    for(var i=0, len=localStorage.length; i<len; i++) {
      var key = localStorage.key(i);
      var value = localStorage[JSON.stringify(key)];
      this.listData = value;
      let keyValu = (key + " : " + value);
      console.log("finalData",Object.keys(localStorage).map(k => localStorage.getItem(k)));
      this.listData = value;
   }
  }

}
