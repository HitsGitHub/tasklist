import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reminder-using-bootstrap',
  templateUrl: './reminder-using-bootstrap.component.html',
  styleUrls: ['./reminder-using-bootstrap.component.css']
})
export class ReminderUsingBootstrapComponent implements OnInit {
  taskStatus =  [
  {id: 1, status: "Started"}, 
  {id: 2, status: "Late" },
  {id: 3, status:"Today" },
  {id: 4, status: "Upcoming"},
  {id: 5, status: "Completed"}
] 

  saveData = [];
  public id: number;
  public task: string;
  public status: number;
  public rows: Array<{id: number, name: string, year: number}> = [];

  buttonClicked() {
    this.rows.push( {id: this.id, name: this.task, year: this.status } );

    //if you want to clear input
    this.id = null;
    this.task = null;
    this.status = null;
  }
  constructor() { }

  ngOnInit() {

  }
  onSubmit(){

  }
  onChange(statusindex){
    console.log(statusindex);
  }
}
