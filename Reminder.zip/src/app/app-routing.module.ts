import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReminderUsingBootstrapComponent } from './reminder-using-bootstrap/reminder-using-bootstrap.component';
import { StatusReportComponent } from './status-report/status-report.component';

const routes: Routes = [
  {
    path : '', pathMatch : 'full',redirectTo : 'reminder'
  },
  {
    path: 'reminder', component:ReminderUsingBootstrapComponent
  },
  {
    path: '**', redirectTo:'reminder'
  },
  {
    path: "statusReport", component: StatusReportComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
