import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import {Observable,of} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class JsonService {
  item : [];
  constructor(private http : HttpClient) {
    this.getJsonData().subscribe(data => {
      this.item = data;      
    });
    
  }
  public getJsonData():Observable<any>{
    return this.http.get("assets/CarData.json");
  }
}
