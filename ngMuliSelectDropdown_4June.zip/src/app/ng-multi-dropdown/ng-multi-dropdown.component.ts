import { Component, OnInit } from '@angular/core';
import { JsonService } from '../json.service';
import { from } from 'rxjs';
import { FormGroup, FormBuilder, FormArray, FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-ng-multi-dropdown',
  templateUrl: './ng-multi-dropdown.component.html',
  styleUrls: ['./ng-multi-dropdown.component.css']
})
export class NgMultiDropdownComponent implements OnInit {
  myForm: FormGroup;
  modelList = [];
  dropdownList1 = [];
  dropdownList2 = [];
  selectedItems1 = [];
  selectedItems2 = [];
  dropdownSettings1 = {};
  dropdownSettings2 = {}
  carModels: any = [];
  mainCars = [];
  mainModels = [];
  saveSelectedData: any[];

  constructor(private jsonService: JsonService,
    private _fb: FormBuilder,
  ) {
    this.myForm = this._fb.group({
      modelList: new FormControl({})
    });
    this.addCheckboxes();
  }
 
  ngOnInit() {
    this.jsonService.getJsonData().subscribe(data => {

      for (let i = 0; i < data.length; i++) {
        this.mainCars.push({ item_id: i, item_text: data[i].car })
        this.dropdownList1 = this.mainCars;      
      }
      this.modelList = data;
     // console.log("this.mainModelst",this.mainModels);
      
        /* this.mainCars.push({ item_id: i, item_text: data[i].car })
        this.modelList = data
        for (let j = 0; j < data[i].model.length; j++) {
          this.mainModels.push({ item_id: i, item_text: data[i].model[j].model_name })
        } 
      }
      this.dropdownList1 = this.mainCars;      
      this.dropdownList2 = this.mainModels; */
    });

    this.dropdownSettings1 = {
      singleSelection: true,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      itemsShowLimit: 1,
      allowSearchFilter: false,
    };
    this.dropdownSettings2 = {

      idField: 'item_id',
      singleSelection: false,
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true,
      enableCheckAll: true,
      
    };
  }


  onItemSelect1(item: any) {
      this.modelList.filter(element=>{
        if(element.car == item.item_text){
          this.mainModels = element.model;
         console.log("this.dropdown2",this.mainModels);
         
         for (let i = 0; i < this.mainModels.length; i++) {
          console.log("this",this.mainModels[i].model_name);
          this.dropdownList2.push({item_id : i,item_text : this.mainModels[i].model})
         }
        }
        
      })
    }
  onItemSelect2(item: any) {
    console.log("you select",item);
    
  }
  onSelectAll2(items: any) {
    console.log(items);
    for (let i = 0; i < items.length; i++) {
    }
 
  }
  onItemDeSelect2(items: any) {

  }
  onChange(ev){
    this.dropdownList2.splice(0);
  }

  /*  Create Dynamic Checkbox List */
  private addCheckboxes() {
    this.modelList.map((o, i) => {
      const control = new FormControl(i === 0); // if first item set to true, else false
      (this.myForm.controls.modelList as FormArray).push(control);
    });
  }
  submit() {
    this.myForm.reset();
    console.log("Form Values", this.myForm.value);

  }
}
