import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-final-quiz',
  templateUrl: './final-quiz.component.html',
  styleUrls: ['./final-quiz.component.css']
})
export class FinalQuizComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
