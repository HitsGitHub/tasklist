import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators, FormArray } from '@angular/forms'
import { QuizDataService } from '../quiz-data.service';


@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {
  quizForm: FormGroup;
  title = "Quiz Wizard"
  radioSel: any;
  radioSelected: string;
  radioSelectedString: string;
  itemsList: any;

  Questions: any
  Que: any;
  Answers = []
  typeOfAnswer = []
  QueType = [];
  correctIndex: []
  Ans = [];
  x: number = 0
  //4th julyy
  ansArray : Array <{opt:string, id:number}> = [];
  ArrayofAns = [];

  constructor(private quizdataservice: QuizDataService,
    private fb: FormBuilder) {
  }

  ngOnInit() {
    this.quizForm = this.fb.group({
      btn_radio:this.fb.array (['']),
      txtbox: [''],
      val_check: this.fb.array (['']),
      
    })
    this.quizdataservice.getQuizdata().subscribe(data => {
      this.Questions = data.questions
      
      for (let i = 0; i < 5; i++ , this.x++) {
        this.Ans.push(this.Questions[i].answers)
        this.QueType.push(this.Questions[i].types)
      }
     this.Answers = this.Ans
      this.typeOfAnswer = this.QueType
   
   /*   this.Questions.types.forEach(aa=>{
        console.log("aa",aa);
       this.quizForm.addControl(aa.questions,this.fb.control(null, Validators.required));
        
      }) */

    },
      error => {
        console.log("Data Not Fatch", error)
      })
  }
 
  temp = [];
  
  onRadioBtnChange(value:string,i:number,isChecked : boolean) {    
    console.log(value);
    console.log(isChecked);
   /*  this.Answers.forEach(item => {
      if (item.id !== i) {
        item.selected = false;
      } else {
        item.selected = true;
      }
    })  */
    const radioButnFormArray = <FormArray>this.quizForm.controls.btn_radio;
    if (isChecked) {
      radioButnFormArray.push(new FormControl(value));
    } else {
      let index = radioButnFormArray.controls.findIndex(x => x.value == value)
      radioButnFormArray.removeAt(index);
    }
  }
  selectedChBox(value: string,isChecked: boolean) {
    console.log("Checkvalue",value);
    console.log(isChecked);

    const ChkBoxFormArray = <FormArray>this.quizForm.controls.val_check;

    if (isChecked) {
      ChkBoxFormArray.push(new FormControl(value));
    } else {
      let index = ChkBoxFormArray.controls.findIndex(x => x.value == value)
      ChkBoxFormArray.removeAt(index);
    }
  }
  onSubmit() {
    console.log(this.quizForm.value);
    localStorage.setItem("QuizAnswer", JSON.stringify(this.quizForm.value));
  }
}
