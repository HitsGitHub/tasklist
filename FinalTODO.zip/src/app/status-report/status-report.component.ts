import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-status-report',
  templateUrl: './status-report.component.html',
  styleUrls: ['./status-report.component.css']
})
export class StatusReportComponent implements OnInit {
  saveData = [];

  today = Date.now();
  fixedTimezone = this.today

  constructor() { }

  ngOnInit() {
  }

}
