import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Time } from '@angular/common';
import { FormArray, FormGroup, FormBuilder } from '@angular/forms';
import * as jsPDF  from 'jspdf';
import {HttpClient} from '@angular/common/http';
import { from } from 'rxjs';


@Component({
  selector: 'app-reminder-using-bootstrap',
  templateUrl: './reminder-using-bootstrap.component.html',
  styleUrls: ['./reminder-using-bootstrap.component.css']
})
export class ReminderUsingBootstrapComponent implements OnInit {

  myForm: FormGroup;
  saveData = [];
  complete : boolean = false;
  selectedStatus: string = '';
  isDisabled: boolean;

  taskStatus = [
    { id: 1, status: "Started" },
    { id: 2, status: "Late" },
    { id: 3, status: "Today" },
    { id: 4, status: "Upcoming" },
    { id: 5, status: "Completed" }
  ]

  constructor(private fb: FormBuilder,private httpService : HttpClient) {

  }

  ngOnInit() {
    
    this.myForm = this.fb.group({
      ctask: "",
      cstatus: "",
    })
  }
   todoClear(){
    this.taskStatus.splice(0);
  } 
  /* ======CURENT TIME======== */
  today = Date.now();
  fixedTimezone = this.today

  /* -------- Getting Status -------- */
  onChange(valueofDropdown:any) {
    
    this.taskStatus.filter(task => {
      this.selectedStatus = valueofDropdown;  
      console.log("",);
      
    });
  }

  onSubmit() {

    this.saveData.push(this.myForm.value);
    //console.log(this.saveData);
    if (this.selectedStatus == "Completed"){

    }
  }
  

  /* GENERATE PDF REPORT START */
  @ViewChild('reportContent') reportContent: ElementRef;

  downloadPdf() {
    const doc = new jsPDF('p', 'mm', 'a4');
    const specialElementHandlers = {
      '#editor': function (element, renderer) {
        return true;
      }
    };
    const content = this.reportContent.nativeElement;
    doc.fromHTML(content.innerHTML, 15, 10, {
      
      'position': 'Landscape',
      'width': 0,
      'elementHandlers': specialElementHandlers
    });
    doc.save('ReminderReport' + '.pdf');
  }


}
