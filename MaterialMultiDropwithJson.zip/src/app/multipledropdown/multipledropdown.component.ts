import { Component} from '@angular/core';
import { JsonDataService } from '../json-data.service';
import {FormArray, FormBuilder, FormControl, FormGroup} from '@angular/forms';
import { element } from '@angular/core/src/render3';
import { of } from 'rxjs';


@Component({
  selector: 'app-multipledropdown',
  templateUrl: './multipledropdown.component.html',
  styleUrls: ['./multipledropdown.component.css'],
  
})

export class MultipledropdownComponent {
  myForm: FormGroup;//Checkbox group Array.Form
  CarBrand = [];
  model = [];
  color = [];
  listData = [];
  name:string;
  selectedBrands: string;
  selectedModels : string;
  printedOption: string;

  constructor(private jsonservice : JsonDataService, private _fb: FormBuilder) {
  
    this.myForm = _fb.group({
      published : true,                 // Form Control
      credentials : this._fb.array([])  // Form Array
    });
    console.log(this.myForm);
   }

  ngOnInit() {
    this.jsonservice.getJSONData().subscribe(data=>{
        this.CarBrand = data;
    }); 
  }

  brandChange(e) {
    localStorage.setItem("Brand",e);
    this.CarBrand.filter(element => {  
        if(element.car == e){
          this.model = element.model;
      }    
     //console.log(e, ' ',element.car,'',element.model,'',); 
    });

    this.color = []
  }

  modelChange(evt) {
    console.log("evt",evt);
    console.log("length", evt.length);
    
    localStorage.setItem("Model_name",evt)
    this.model.filter(element => {
      if (element.name == evt) {
        this.color = element.name        
      }
    });
  }

  /* btnSave($event){
    localStorage.setItem("Saved Data",$event);
    Object.keys(localStorage);
    for(var i=0, len=localStorage.length; i<len; i++) {
      var key = localStorage.key(i);
      var value = localStorage[JSON.stringify(key)];
      this.listData = value;
      let keyValu = (key + " : " + value);
      console.log("finalData",Object.keys(localStorage).map(k => localStorage.getItem(k)));
      this.listData = value;
   }
  } */

  submit(){
    console.log("formdata",this.myForm);
   /*  const selectedCarmodel = this.myForm.value.modelChange .map((v, i) => v ? this.modelChange[i].id : null)
    .filter(v => v !== null);
    console.log("selected model",selectedCarmodel); */
    this.printedOption = localStorage.getItem("Model_name");
    
  }
  get selectedOptions() { // right now: ['1','3']
    return this.model
              .filter(opt => opt.checked)
              .map(opt => opt.value)
  }
  
}
