import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormControl, FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { Observable } from 'rxjs';
import {JsonServiceService} from 'src/app/json-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  myForm: FormGroup;
        submitted = false;
        getdata=[];
        mul_city=[];
        countryModel;
        cityModel;
        mycity=[];
        filteredStates:any[];
        filteredCity: any [];
        filteredValues:any[];
        storeState : any  [] ;
        storeCities: any = [];
        newStoreVal=[];
        countries = [];
        cities=[];
        limitSelection = false;
        selectedItems: any = [];
        dropdownSettings: any = {};
        dropdownSettings1: any = {};
        closeDropdownSelection=false;
        AllCountry = [];

    constructor(private http: HttpClient,private formBuilder: FormBuilder,
      private JSon: JsonServiceService){
      this.JSon.getJsonData().subscribe(data=>{    
        console.log("data",data);
        
        this.countries = data;
        this.dropdownSettings1 = {
          singleSelection: true,
          idField: 'countryName',
          textField: 'countryName',
          closeDropDownOnSelection: true
          };
         for(let country of this.countries){
           this.cities.push(country.cities);           
          }  
          console.log("this.cities",this.cities);
       })
    }
  
    ngOnInit(){
    this.getdata = JSON.parse(localStorage.getItem('Mydata'));
    this.myForm = this.formBuilder.group({
      country:[],
      state:[],
      checkboxes: new FormArray([]),
      
    })
    this.addCheckboxes();
  }
  onSelectCountry(cuntry){
  console.log("country Select",cuntry);
    this.filteredStates = this.countries.find(con => con.countryName == cuntry).cities;
    console.log("this.filteredStates",this.filteredStates);
     this.dropdownSettings = {
      singleSelection: false,
      idField: 'id',
      textField: 'name',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3
      };
  }
  deselectCountry(deselectCountry){
    console.log("DeselectCountry",deselectCountry);
  }
  onStateSelect(state) {
    this.mul_city.push(state.name);
    for(var j=0;j<=this.mul_city.length;j++){
      this.filteredCity = this.filteredStates.find(con => con.name[j] === state.name[j]).values;
    }
    console.log("filtered City",this.filteredCity);
    this.storeCities.push(this.filteredCity)
  }
  onStateDeSelect(deSelectState){
    console.log(deSelectState);
    
    this.filteredCity.splice(0);
  }
  onSelectAllState(items: any) {
    console.log('onSelectAllState', items);
    for (let i = 0; i < items.length; i++) {
      this.mul_city.push(items[i].name)      
    }
    console.log("this.mul_city",this.mul_city);    
  }
  onDeselectAllState(allStates: any){
    console.log("onDeselectAllState",allStates);
    this.mul_city.splice(0);
    console.log("multi_select",this.mul_city);
    
  }
  toggleCloseDropdownSelection() {
    this.closeDropdownSelection = !this.closeDropdownSelection;
    this.dropdownSettings1 = Object.assign({}, this.dropdownSettings1,{closeDropDownOnSelection: this.closeDropdownSelection});
  }
  onSubmit(){
    this.submitted = true;
    console.log("submitted");
    
    const selectedOrderIds = this.myForm.value.checkboxes
    .map((v, i) => v ? this.filteredValues[i].name:null);
     // .filter(v => v !== null);
    console.log(selectedOrderIds);
    (this.myForm.controls.checkboxes as FormArray).setValue(selectedOrderIds);
            
    localStorage.setItem('Mydata', JSON.stringify(this.myForm.value));
    this.myForm.reset();
    
  }
  private addCheckboxes() {
    this.storeCities.map((o, i) => {
      const control = new FormControl(); // if first item set to true, else false
      (this.myForm.controls.checkboxes as FormArray).push(control);
    });
  }
  
  handleLimitSelection() {
    if (this.limitSelection) {
        this.dropdownSettings = Object.assign({}, this.dropdownSettings, { limitSelection: 2 });
    } else {
        this.dropdownSettings = Object.assign({}, this.dropdownSettings, { limitSelection: null });
    }
  }
}
