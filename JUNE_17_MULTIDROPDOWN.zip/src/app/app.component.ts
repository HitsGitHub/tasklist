import { Component,} from '@angular/core';
import {FormBuilder,FormGroup,FormArray, FormControl} from '@angular/forms';
import { HttpClient} from '@angular/common/http';
import { JsondataService} from './jsondata.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 
  myForm:FormGroup;

  submitted = false;
  disabled = false;
  ShowFilter = false;
  limitSelection = false;
  country = [];
  citiess = [];
  state = [];

  dropdownSettings1: any = {};
  dropdownSettings2: any = {};
  countrydata = [];
  statedata =[];
  citydata = [];
  mult_state = [];
  AllCountries=[];
  AllStates = [];
  AllCities=[];
  
  storeCity = [];
  storeState =[];
  filteredValues =[];
  h1 = [];
  h2 = [];
  jsondata : any;

  constructor(private fb: FormBuilder, 
              private http : HttpClient,
              private jSon:JsondataService) {
  }

  ngOnInit() {
    
    this.myForm = this.fb.group({
      country : [],
      state:[],
      citiess:new FormArray([]),
      checkboxes : new FormArray([]),
    })
    this.addCheckboxes();

      this.jSon.getJsonData().subscribe(response=>{
        this.jsondata = response;
        this.AllStates = this.jsondata.states;
        this.AllCities = this.jsondata.cities;
        for (let i = 0; i < this.jsondata.countries.length; i++) {
          this.AllCountries.push({item_id: i, item_text: this.jsondata.countries[i].name});
          this.country = this.AllCountries      
        } 
        this.dropdownSettings1 = {
          singleSelection: true,
          idField: 'item_id',
          textField: 'item_text',
          unSelectAllText: 'UnSelect All',
          itemsShowLimit: 3,
          allowSearchFilter: this.ShowFilter,
          closeDropDownOnSelection: true,
          }; 
      })
      this.dropdownSettings2 = {
        singleSelection: false,
        idField: 'item_id',
        textField: 'item_text',
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        itemsShowLimit: 3,
        allowSearchFilter: this.ShowFilter,
        closeDropDownOnSelection: true,
        enableCheckAll : false,
      };
  }
  onSelectCountry(item : any) { 
    this.h1.splice(0);
    this.statedata = this.AllStates.filter(x=>
      x.country_id == item.item_id)
      for (let i = 0; i < this.statedata.length; i++) {
        this.h1.push({item_id: i, item_text: this.statedata[i].name});
      }
      this.state = this.h1;
      console.log('this.state',this.state);
  }
  onSelectState(item: any) {
    
    console.log('state.name',item);
    this.mult_state.push(item); 
    console.log("mul_state",this.mult_state);
    
    this.citydata = this.AllCities.filter(x=>
      x.state_id == item.item_id)
      for (let i = 0; i < this.citydata.length; i++) {
        this.h2.push({item_id: this.citydata[i].id, item_text:this.citydata[i].name})  
      }
      this.citiess = this.h2;
      console.log("this.citiess",this.citiess);
  }
  
  onCountryChange(change){
    console.log("changecountry",change);
    this.state=[];
  }
  onCountryDeselect(item: any){
    console.log("Deselect Country",item);
    this.state.splice(0);
  }
 
  onStateDeSelect(item : any){
  console.log("DeselectState",item);
    this.citiess.splice(0);
    this.state= [];
  }
 
  toogleShowFilter() {
      this.ShowFilter = !this.ShowFilter;
      this.dropdownSettings1 = Object.assign({}, this.dropdownSettings1, { allowSearchFilter: this.ShowFilter });
  }

  handleLimitSelection() {
      if (this.limitSelection) {
          this.dropdownSettings1 = Object.assign({}, this.dropdownSettings1, { limitSelection: 2 });
      } else {
          this.dropdownSettings1 = Object.assign({}, this.dropdownSettings1, { limitSelection: null });
      }
  }
  private addCheckboxes() {
    this.citiess.map((o, i) => {
      const control = new FormControl(i===0); // if first item set to true, else false
      (this.myForm.controls.checkboxes as FormArray).push(control);
    });
  }
 
  onSubmit(){
    this.submitted = true;
    this.citiess.map((o,i)=>{
      const control = new FormControl(i === 0);  // if first item set to true, else false
      (this.myForm.controls.citiess as FormArray).push(control);
    });
    const selectedOrderIds = this.myForm.value.citiess.map((v, i) => v ? this.citiess[i].item_text:this.citiess[i].item_text)
    console.log("selectedCheckboxOrderIDs",selectedOrderIds);
    (this.myForm.controls.citiess as FormArray).setValue(selectedOrderIds); 
    localStorage.setItem('Form_Data', JSON.stringify(this.myForm.value));
    this.myForm.reset();
  }
}
