import { Component, OnInit } from '@angular/core';
import { JsonService } from '../json.service';
import { from } from 'rxjs';
import { FormGroup, FormBuilder, FormArray, FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-ng-multi-dropdown',
  templateUrl: './ng-multi-dropdown.component.html',
  styleUrls: ['./ng-multi-dropdown.component.css']
})
export class NgMultiDropdownComponent implements OnInit {
  myForm: FormGroup;
  modelList;
  dropdownList1 = [];
  dropdownList2 = [];
  selectedItems1 = [];
  selectedItems2 = [];
  dropdownSettings1 = {};
  dropdownSettings2 = {}
  carModels: any = [];
  mainCars = [];
  mainModels = [];
  saveSelectedData: any[];

  constructor(private jsonService: JsonService,
    private _fb: FormBuilder,
  ) {
    this.myForm = this._fb.group({
      modelList: new FormControl({})
    });
    this.addCheckboxes();
  }
  a = [];
 
  ngOnInit() {
    this.jsonService.getJsonData().subscribe(data => {

      for (let i = 0; i < data.length; i++) {
        this.mainCars.push({ item_id: i, item_text: data[i].car })
        this.a.push({ item_id: i, item_text: data[i].model })
        for (let j = 0; j < data[i].model.length; j++) {
          this.mainModels.push({ item_id: i, item_text: data[i].model[j].model_name })
        }
      }
      console.log("this.mainModule",this.mainModels);
      
      this.a = this.mainModels.filter(aa=>{
        return aa.item_id == this.modelList
      })
      console.log(this.a);
      
      this.dropdownList1 = this.mainCars;
     // this.dropdownList2 = this.mainModels;// all model stored here
    });

    this.dropdownSettings1 = {
      singleSelection: true,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      itemsShowLimit: 1,
      allowSearchFilter: false,
    };
    this.dropdownSettings2 = {

      idField: 'item_id',
      singleSelection: false,
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true,
      enableCheckAll: true,
      
    };
  }

  /* onItemSelect1  dropdown2 value change*/
  onItemSelect1(item: any) {
    
      this.dropdownList2 = this.mainModels.filter(x =>
        (x.item_id == item.item_id)
      ) 
     console.log("Dropdown2", this.dropdownList2);
    
      this.dropdownList1.splice(0);
  }

  /* onItemSelect2  for DropDown 2*/
  onItemSelect2(item: any) {
    console.log("you select",item);
    
  }
  onSelectAll2(items: any) {
    console.log(items);
    for (let i = 0; i < items.length; i++) {
      this.a = items[i];
    }
 
  }
  onItemDeSelect2(items: any) {

  }
  onChange(ev){
    this.dropdownList2.splice(0);
  }

  /*  Create Dynamic Checkbox List */
  private addCheckboxes() {
    this.modelList.map((o, i) => {
      const control = new FormControl(i === 0); // if first item set to true, else false
      (this.myForm.controls.modelList as FormArray).push(control);
    });
  }
  submit() {
    this.myForm.reset();
    console.log("Form Values", this.myForm.value);

  }
}
