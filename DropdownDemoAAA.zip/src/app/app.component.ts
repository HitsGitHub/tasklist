import { Component } from '@angular/core';
import { Form } from '@angular/forms';
import { MatFormFieldControl } from '@angular/material';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  selectedBrand = [];
  selectedModel = [];
  model = [];
  color = [];
  CarBrand = [
    {
      "car": "JAGUAR",
      "model": [
        {
          "name": "Jaguar XF",
          "color": [
            "Dark Black",
            "Hot Red",
            "White"
          ]
        },
        {
          "name": "Jaguar XL",
          "color": [
            "Black",
            "Red",
            "White"
          ]
        },
        {
          "name": "Jaguar XE",
          "color": [
            "Blue",
            "Black",
            "White"
          ]
        }
      ]
    },
    {
      "car": "AUDI",
      "model": [
        {
          "name": "Audi R8",
          "color": [
            "Yellow",
            "Pink",
            "Blue"
          ]
        },
        {
          "name": "Audi S5",
          "color": [
            "dark night",
            "mattel White",
            "Yellow"
          ]
        },
        {
          "name": "Audi A6",
          "color": [
            "White",
            "Black",
            "Red"
          ]
        },
        {
          "name": "Audi Q5",
          "color": [
            "Gray",
            "Pink",
            "Blue"
          ]
        },
        {
          "name": "Audi Q3",
          "color": [
            "Dark Black",
            "White",
            "Gray"
          ]
        }
      ]
    },
    {
      "car": "BMW",
      "model": [{
        "name": "X1",
        "color": [
          "Dark Blue",
          "Black",
          "Red"
        ]
      },
      {
        "name": "Z4",
        "color": [
          "Gray",
          "Blue",
          "Black"
        ]
      },
      ]
    }
  ]


  brandChange(e) {

    this.selectedBrand = e;
    this.CarBrand.filter(element => {
      if (element.car == e) {
        this.model = element.model;
      }
    });
    this.color = []
  }
  modelChange(evt) {
    this.selectedModel = evt;
    this.model.filter(element => {
      if (element.name == evt) {
        this.color = element.color;
      }
    })
  }
}
