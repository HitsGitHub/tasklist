import { Component,} from '@angular/core';
import {FormBuilder,FormGroup,FormArray, FormControl} from '@angular/forms';
import { HttpClient} from '@angular/common/http';
import { JsondataService} from './jsondata.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 
  myForm:FormGroup;
  submitted = false;
  disabled = false;
  ShowFilter = false;
  limitSelection = false;
  country : any = [];
  citiess: any = [];
  state: any = [];
  dropdownSettings1: any = {};
  dropdownSettings2: any = {};
  countrydata = [];
  statedata =[];
  citydata=[];
  
  mult_state = [];
  mult_city = [];

  AllCountries=[];
  AllStates = [];
  AllCities=[];
  
  storeCity = [];
  storeState =[];
  filteredValues =[];
  h1 = [];
  h2 = [];
  jsondata : any;

  constructor(private fb: FormBuilder, private http : HttpClient,private jSon:JsondataService) {
    
  }

  ngOnInit() {
    this.myForm = this.fb.group({
      country:[''],
      state:[''],
      city:[''],
      checkboxes: new FormArray([]),
      chkbox:new FormArray([])
     
    })
      this.jSon.getJsonData().subscribe(response=>{
        this.jsondata = response[0];
        this.AllStates = this.jsondata.states;
        this.AllCities = this.jsondata.cities;
        for (let i = 0; i < this.jsondata.countries.length; i++) {
          this.AllCountries.push({item_id: i, item_text: this.jsondata.countries[i].name});
          this.country = this.AllCountries          
        } 
        this.dropdownSettings1 = {
          singleSelection: true,
          idField: 'item_id',
          textField: 'item_text',
          unSelectAllText: 'UnSelect All',
          itemsShowLimit: 3,
          allowSearchFilter: this.ShowFilter,
          closeDropDownOnSelection: true
        }; 
      })
      this.dropdownSettings2 = {
        singleSelection: false,
        idField: 'item_id',
        textField: 'item_text',
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        itemsShowLimit: 3,
        allowSearchFilter: this.ShowFilter,
        closeDropDownOnSelection: true
      };
  }
  
  onSelectCountry(item : any) {    
   this.statedata = this.AllStates.filter(x=>
      x.country_id == item.item_id
    )
   for (let i = 0; i < this.statedata.length; i++) {
      this.h1.push({item_id: this.statedata[i].id, item_text:this.statedata[i].name})
      this.state = this.h1;
    } 
  }
  onSelectState(item: any) {
    console.log("itemState",item);
    this.storeState.push(item.item_text);
    console.log("storeState",this.storeState);
    
    this.mult_state.push(this.storeState);
    console.log("mul_state",this.mult_state);
    
    this.citydata = this.AllCities.filter(x=>
        x.state_id == item.item_id
      ) 
      console.log("cityDta",this.citydata);
      for (let i = 0; i < this.citydata.length; i++) {
        this.storeCity.push(this.citydata[i])        
      }
      console.log("storeCity",this.storeCity);
      this.mult_city = this.storeCity;  
      console.log("mul_city",this.mult_city); 
  }
  onCitySelect(item: any){
    console.log(item);
    
  }
  onSelectAll(items: any) {
      console.log('onSelectAll1', items);
      
  }
 
  toogleShowFilter() {
      this.ShowFilter = !this.ShowFilter;
      this.dropdownSettings1 = Object.assign({}, this.dropdownSettings1, { allowSearchFilter: this.ShowFilter });
  }

  handleLimitSelection() {
      if (this.limitSelection) {
          this.dropdownSettings1 = Object.assign({}, this.dropdownSettings1, { limitSelection: 2 });
      } else {
          this.dropdownSettings1 = Object.assign({}, this.dropdownSettings1, { limitSelection: null });
      }
  }
 
  onSubmit(){
    this.submitted = true;
    console.log("submitted");
    
    const selectedOrderIds = this.myForm.value.checkboxes
    .map((v, i) => v ? this.filteredValues[i].name:null);
     // .filter(v => v !== null);
    console.log(selectedOrderIds);
    (this.myForm.controls.checkboxes as FormArray).setValue(selectedOrderIds);
            
    localStorage.setItem('Mydata', JSON.stringify(this.myForm.value));
    this.myForm.reset();
  }
}
