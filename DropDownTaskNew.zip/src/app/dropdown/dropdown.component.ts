import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms'
import { ShowOnDirtyErrorStateMatcher } from '@angular/material/core';
import { JsondataService } from '../jsondata.service';
import { Data } from '@angular/router';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css']
})
export class DropdownComponent {
  public myModelProperty: Array<any>;
  dropdownData: any;

  constructor(private jsonDataService : JsondataService) { }

  MainCars = [];
  carModel = [];
  listSelectedcars = [];
  gettingcarmodel:string;

  ngOnInit(){
    this.jsonDataService.getJSON().subscribe(data => {
      for(var brand in data[0].cars)// Audi, BMW, Jaguar
      this.MainCars.push(brand);
      console.log("Car Company:",this.MainCars);

      for(var carname in data[0].cars);
      this.carModel.push(carname);
      console.log("Car Model:",this.carModel[0]);
      for(let i =0; i<this.carModel.length; i++)
      {
      }
     });
  }

  firstDropDownChanged(){
    
  }
  get carmodel():string[]{
    return Array.from(this.MainCars)

  }

/*   carcompany;
  carModels;
  carList = [];
  
  carsInfo= {
    a1: "AUDI",
    b1: "Audi R8",
  
  }
  carModelList : any = [
    {
    
        'carcompanyName':'AUDI',
        carList: [
        'Audi R8', 'Audi A6'
        ]
    },
    {
      'carcompanyName' : 'JAGUAR',
      carList :[
        'Jaguar XL', 'Jagura XF'
      ]  
    },
    {
      'carcompanyName' : ' BMW',
      carList :[
        'BMW X1','BMW Q3'
      ]
    }
  ];
  
  editInfo(carsInfo) {
    this.carcompany = carsInfo.a1;    
    this.carModels = carsInfo.b1;
    this.carsChangeAction(this.carcompany);
  }

  carsChangeAction(cars)
  {   
    {
      //this.carModels="";
      let dropDownData = this.carModelList.find((data: any) => data.carcompanyName === cars);
      
      
      if (dropDownData) {
        this.carList = dropDownData.carList;
        
        if(this.carList){
          this.carModels=this.carList[0];
        }
        
      } else {
        this.carList = [];
      }

    }
  } */

 
}
