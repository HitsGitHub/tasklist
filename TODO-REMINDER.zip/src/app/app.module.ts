import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TodoReminderComponent } from './todo-reminder/todo-reminder.component';
import { HttpClientModule } from '@angular/common/http';
import {DropdownModule} from 'angular-dropdown-component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { Time } from '@angular/common';
import { FormArray, FormGroup, FormBuilder } from '@angular/forms';
import * as jsPDF  from 'jspdf';
import {HttpClient} from '@angular/common/http';
import { from } from 'rxjs';
import { text } from '@angular/core/src/render3';

@NgModule({
  declarations: [
    AppComponent,
    TodoReminderComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule,
    AppRoutingModule,DropdownModule,ReactiveFormsModule,NgbModule.forRoot(),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
