import { Component, OnInit, ViewChild, ElementRef} from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import * as jsPDF  from 'jspdf';

@Component({
  selector: 'app-todo-reminder',
  templateUrl: './todo-reminder.component.html',
  styleUrls: ['./todo-reminder.component.css']
})
export class TodoReminderComponent implements OnInit {

  myForm: FormGroup;
  saveData = [];
  complete : boolean = false;
  isDisabled: boolean;
  checkarray: any[] = [];
  public selectedId : any;
  public selectedstatus: any[] = [];   
  public table_data: any;

  taskStatus = [
    { id: 1, status: "Started" },
    { id: 2, status: "Late" },
    { id: 3, status: "Today" },
    { id: 4, status: "Upcoming" },
    { id: 5, status: "Completed" }
  ]
  constructor(private fb: FormBuilder,private httpService : HttpClient) { }

  ngOnInit() {
    this.myForm = this.fb.group({
      ctask: "",
      cstatus: "",
    })
  }

  onSubmit() {

    this.saveData.push(this.myForm.value);
    //console.log(this.saveData);
    
  }

  todoClear(){
    this.taskStatus.splice(0);
  }

  /* ----------CURENT TIME ---------*/
  today = Date.now();
  fixedTimezone = this.today

  /* -------- Getting Status -------- */
  onChange(selectedDropValue:any) {
    
    if(selectedDropValue == "Completed"){
      
    }
    else{
      //console.log("valueee",selectedDropValue);
   }
  }

  changeStatus(e, id) {

    this.table_data = document.getElementById("my-table");
    console.log("tabledata",this.table_data);
    
    for (var i=1, row; row = this.table_data.rows[i]; i++){
        for (var j=0, cell; cell = row.cells[j]; j++){
            if (cell[0].children[0].checked){
                console.log("It is checked");
            }
        }
    }
    /* var status = e.target.checked;
    console.log("Statusss",status);
    var checkbox = document.getElementById("chk");
    console.log("aa",checkbox);
    var text = document.getElementById("text");
    if (e == true){
      text.style.display="Completed";
    } else {
      text.style.display = "none";
    }
 */
    /* this.selectedstatus.changeStatus(id, status).subscribe(result => {
        if (status)
            this.notify.success(this.l('AddedAsKeyPeople'));
        else
            this.notify.success(this.l('RemovedFromKeyPeople'));

    }); */
  } 
    
  
  /* GENERATE PDF REPORT START */
  @ViewChild('reportContent') reportContent: ElementRef;

  downloadPdf() {
    const doc = new jsPDF('p', 'mm', 'a4');
    const specialElementHandlers = {
      '#editor': function (element, renderer) {
        return true;
      }
    };
    const content = this.reportContent.nativeElement;
    doc.fromHTML(content.innerHTML, 15, 10, {
      
      'position': 'Landscape',
      'width': 0,
      'elementHandlers': specialElementHandlers
    });
    doc.save('ReminderReport' + '.pdf');
  }



}
