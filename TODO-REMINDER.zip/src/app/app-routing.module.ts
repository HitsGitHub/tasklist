import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TodoReminderComponent } from './todo-reminder/todo-reminder.component';

const routes: Routes = [
  {
    path : '', pathMatch : 'full',redirectTo : 'reminder'
  },
  {
    path: 'reminder', component:TodoReminderComponent
  },
  {
    path: '**', redirectTo:'reminder'
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
