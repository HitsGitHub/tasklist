import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class JsondataService {

  constructor(private http : HttpClient) {
    this.getJsonData().subscribe(data=>{
      console.log("data",data);
    },
    error=>{
      console.log("json data not fatched");
      
    });

  }
   public getJsonData():Observable<any>{
    return this.http.get("assets/country.json");
  }
  
}
