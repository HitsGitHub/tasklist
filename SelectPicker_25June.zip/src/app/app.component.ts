import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,FormControl,FormArray } from '@angular/forms';
import {JsondataService} from './jsondata.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  
  myForm: FormGroup;
  selectedCountry = 0;
  selectedState = 0;
  selectedCities = 0;
  states = [];
  cities = [];
  gettingStates: any [] = [];
  getiingCities: any [] = [];
  countryData : any [];

  constructor(private jsondata : JsondataService,private fb:FormBuilder){
    this.myForm = fb.group({
      state : new FormControl,
      country : new FormControl,
      city : new FormControl,
      checkboxes : new FormArray([])
    });
  }
  ngOnInit(){
    this.jsondata.getJsonData().subscribe(data=>{
      this.gettingStates = data[0].states;
      this.countryData = data[0].countries;
      this.getiingCities = data[0].cities;
    })
  }
  getCountries() {
    return this.countryData;
  }
  getStates(){
    return this.gettingStates;
  }
  getCity(){
    return this.getiingCities;
  }
  selectCountry( countrid) {  
    this.selectedCountry = countrid;
    console.log("countrid",this.selectedCountry);
    this.cities = [];
    this.states = this.getStates().filter((item) => {
      console.log("item",item.country_id);
      if(countrid === item.country_id)
      {console.log("true");
      }
      else{console.log("false");
      }
      return item.country_id === countrid
  });
    console.log("this.state",this.states);
  } 
  onSelectState(state_id) {
    this.selectedState = state_id;
    this.cities = this.getCity().filter((item) => {
      return item.state_id === state_id
    });
  }
  onItemSelect(item: any) {
    console.log(item);
  }
  onSelectAll(items: any) {
    console.log(items);
  }
  submit(){
    console.log("this.form",this.myForm.value);
  }

}
