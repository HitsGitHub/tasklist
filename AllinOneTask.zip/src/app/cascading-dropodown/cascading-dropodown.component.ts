import { Component, OnInit } from '@angular/core';
import {JsonDataService} from '../json-data.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { element } from '@angular/core/src/render3';

@Component({
  selector: 'app-cascading-dropodown',
  templateUrl: './cascading-dropodown.component.html',
  styleUrls: ['./cascading-dropodown.component.css']
})
export class CascadingDropodownComponent implements OnInit {
  myForm: FormGroup;//Checkbox group Array.Form
  CarBrand = [];
  model = [];
  color = [];
  listData = [];
  name:string;
  selectedBrands: string;
  selectedModels : string;
  printedOption: string;
  
  config = {
    displayKey:"description", 
    search:true, 
    placeholder:'Select',
    customComparator: ()=>{},
    noResultsFound: 'No results found!',
    searchPlaceholder:'Search', 
    searchOnKey: 'name'
  }

  constructor(private jsonservice : JsonDataService, private _fb: FormBuilder) {
  
    this.myForm = _fb.group({
      published : true,                 // Form Control
      credentials : this._fb.array([]),  // Form Array
      selectData : [],

    });
    console.log(this.myForm);
   }

  ngOnInit() {
    this.jsonservice.getJSONData().subscribe(data=>{
       for (let i = 0; i < data.length; i++) {
        const element = data[i];
        console.log("elemnt",element);
        this.CarBrand.push(element);  
        /* this.selectedBrands = element; */
      }            
    }); 
  }

  brandChange(e) {
  localStorage.setItem("Brand",e);
  this.CarBrand.filter(element => {  
    if(element.car == e){
      this.model = element.model;
    }    
  }); 
  this.color = []
   
  }

  modelChange(evt) {
    console.log("evt",evt);
    console.log("length", evt.length);
    
    localStorage.setItem("Model_name",evt)
    this.model.filter(element => {
      if (element.name == evt) {
        this.color = element.name        
      }
    });
  }

  /* btnSave($event){
    localStorage.setItem("Saved Data",$event);
    Object.keys(localStorage);
    for(var i=0, len=localStorage.length; i<len; i++) {
      var key = localStorage.key(i);
      var value = localStorage[JSON.stringify(key)];
      this.listData = value;
      let keyValu = (key + " : " + value);
      console.log("finalData",Object.keys(localStorage).map(k => localStorage.getItem(k)));
      this.listData = value;
   }
  } */

  submit(){
    console.log("formdata",this.myForm);
   /*  const selectedCarmodel = this.myForm.value.modelChange .map((v, i) => v ? this.modelChange[i].id : null)
    .filter(v => v !== null);
    console.log("selected model",selectedCarmodel); */
    this.printedOption = localStorage.getItem("Model_name");
    
  }
  get selectedOptions() { // right now: ['1','3']
    return this.model
              .filter(opt => opt.checked)
              .map(opt => opt.value)
  }
  
}
