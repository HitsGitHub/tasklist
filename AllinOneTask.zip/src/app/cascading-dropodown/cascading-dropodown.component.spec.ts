import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CascadingDropodownComponent } from './cascading-dropodown.component';

describe('CascadingDropodownComponent', () => {
  let component: CascadingDropodownComponent;
  let fixture: ComponentFixture<CascadingDropodownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CascadingDropodownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CascadingDropodownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
