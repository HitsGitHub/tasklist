import { Component, OnInit } from '@angular/core';
import { JsonDataService } from '../json-data.service'
import { Subscriber } from 'rxjs';

@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css']
})
export class DropdownComponent implements OnInit {
  Brands = [];
  selectedBrand = 0;
  selectedModel = 0;
  models = [];
  Carmodels: Array<any>;
  CarBrand : any [] ;
  constructor(private jsondata : JsonDataService ) { }

  ngOnInit() {
    this.jsondata.getJSONData().subscribe(data=>{
      this.CarBrand = data.car;
      console.log("carBrand",this.CarBrand);
      

      for(let i = 0; i < data.length;i++){
       this.Brands.push(data[i].car);
        console.log("Brands",this.Brands);
      }

      for(let i = 0; i < data.length;i++){
        this.models.push(data[i].model[i].name);
        console.log("model_name",this.models);
      } 
     });
     
  }
  changeModels(e){
    console.log("e",e);
    this.CarBrand.filter(element =>{
      if(element.car == e){
        this.models = element.model
      }
    })
  }
}
