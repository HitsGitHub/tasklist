import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormControl, FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { Observable } from 'rxjs';
import {JsonServiceService} from 'src/app/json-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  myForm: FormGroup;
        submitted = false;
        getdata=[];
        mul_city=[];
        mycountry;
        countryModel;
        cityModel;
        mycity=[];
        filteredCities:any[];
        filteredValues:any[];
        storeValues =[];
        newStoreVal=[];
        countries = [];
        cities=[];
        limitSelection = false;
        selectedItems: any = [];
        dropdownSettings: any = {};
        dropdownSettings1: any = {};
        closeDropdownSelection=false;
        AllCountry = [];

    constructor(private http: HttpClient,private formBuilder: FormBuilder,
      private JSon: JsonServiceService){
      this.JSon.getJsonData().subscribe(data=>{    
        console.log("data",data);
        
        this.countries = data;
        this.dropdownSettings1 = {
          singleSelection: true,
          idField: 'id',
          textField: 'item_text',
          closeDropDownOnSelection: true
          
          };
         //console.log(this.countries);
         for(let city of this.countries){
           this.cities.push(city.cities);
          }  
       })
    }
  
    ngOnInit(){
    this.getdata = JSON.parse(localStorage.getItem('Mydata'));
    this.myForm = this.formBuilder.group({
      country:[''],
      city:[''],
      checkboxes: new FormArray([]),
      chkbox : new FormArray([])
    })
      
  }
  getCountry(count){
    console.log("count",count);
    console.log("city list",this.cities);
    this.filteredCities = this.countries.find(con => con.countryName == count).cities;
    // console.log("filtered cities",this.filteredCities);
     this.dropdownSettings = {
      singleSelection: false,
      idField: 'id',
      textField: 'name',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3
      };
  }
  toggleCloseDropdownSelection() {
    this.closeDropdownSelection = !this.closeDropdownSelection;
    this.dropdownSettings1 = Object.assign({}, this.dropdownSettings1,{closeDropDownOnSelection: this.closeDropdownSelection});
  }

  onItemDeSelect(){

  }
  onItemSelect(item) {
  
    this.mul_city.push(item.name);
    console.log("multiple selected city",this.mul_city);
    for(var j=0;j<=this.mul_city.length;j++){
      this.filteredValues=this.filteredCities.find(con => con.name[j] === item.name[j]).values;
    }
    console.log("filtered val",this.filteredValues);
    this.storeValues.push(this.filteredValues);
    console.log("stored values",this.storeValues);
  }
  deselectCon(){

  }
  onSubmit(){
    this.submitted = true;
    console.log("submitted");
    
    const selectedOrderIds = this.myForm.value.checkboxes
    .map((v, i) => v ? this.filteredValues[i].name:null);
     // .filter(v => v !== null);
    console.log(selectedOrderIds);
    (this.myForm.controls.checkboxes as FormArray).setValue(selectedOrderIds);
            
    localStorage.setItem('Mydata', JSON.stringify(this.myForm.value));
    this.myForm.reset();
    
  }
  private addCheckboxes() {
    this.storeValues.map((o, i) => {
      const control = new FormControl(); // if first item set to true, else false
      (this.myForm.controls.checkboxes as FormArray).push(control);
    });
  }
  onSelectAll(items: any) {
    console.log('onSelectAll', items);
  }
  handleLimitSelection() {
    if (this.limitSelection) {
        this.dropdownSettings = Object.assign({}, this.dropdownSettings, { limitSelection: 2 });
    } else {
        this.dropdownSettings = Object.assign({}, this.dropdownSettings, { limitSelection: null });
    }
  }
}
